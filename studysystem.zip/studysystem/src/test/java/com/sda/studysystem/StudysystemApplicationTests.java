package com.sda.studysystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudysystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
